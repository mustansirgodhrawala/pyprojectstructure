# pyprojectstructure
![Tests](https://github.com/mustansirgodhrawala/pyprojectstructure/actions/workflows/tests.yml/badge.svg)
![Docs](https://img.shields.io/readthedocs/pyprojectstructure)
![License](https://img.shields.io/github/license/mustansirgodhrawala/pyprojectstructure?style=flat-square)
![Test Coverage](https://raw.githubusercontent.com/mustansirgodhrawala/pyprojectstructure/main/coverage/coverage.svg)

Hi, there! Welcome 
This a simple repo with a basic python project structure with folders, tests and tox setup.

We have docs on readthedocs.io check description on Github for the link.
