def print_hello():
    print("Hello, World!")


def custom_print(name):
    print(f"Hello, {name}!")
